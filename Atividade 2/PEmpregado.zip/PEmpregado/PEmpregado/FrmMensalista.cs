﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PEmpregado
{
    public partial class FrmMensalista : Form
    {
        public FrmMensalista()
        {
            InitializeComponent();
        }

        private void FrmMensalista_Load(object sender, EventArgs e)
        {

        }

        private void btnMensalista_Click(object sender, EventArgs e)
        {
            //empregado nao pode ter objeto porque é abstrato
            //cria um objeto que vem da classe 
            Mensalista objMensalista = new Mensalista();

            //usando o set das propriedades
            objMensalista.NomeEmpregado = txtNome.Text;
            objMensalista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objMensalista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            objMensalista.SalarioMensal = Convert.ToDouble(txtSalario.Text);

            //usando o get das propriedades
            MessageBox.Show("Nome = " + objMensalista.NomeEmpregado +
                "\nMatrícula = " + objMensalista.Matricula +
                "\nTempo Trabalho = " + objMensalista.TempoTrabalho() +
                "\nSalário Final = " + objMensalista.SalarioBruto().ToString("N2")); //converte em texto e coloca 2 casas decimais
        }

        private void btnMensalistaParam_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista(
                Convert.ToInt32(txtMatricula.Text),
                txtNome.Text,
                Convert.ToDateTime(txtData.Text),
                Convert.ToDouble(txtSalario.Text)
                );

            MessageBox.Show("Nome = " + objMensalista.NomeEmpregado +
                "\nMatrícula = " + objMensalista.Matricula +
                "\nTempo Trabalho = " + objMensalista.TempoTrabalho() +
                "\nSalário Final = " + objMensalista.SalarioBruto().ToString("N2"));
        }
    }
}
