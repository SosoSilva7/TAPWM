﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PEmpregado
{
    internal class Mensalista : Empregado
    {
        public Double SalarioMensal {  get; set; } // nao permite escrever codigo com essa propriedade
        
        //sobreescrevendo o metodo
        public override double SalarioBruto()
        {
            return SalarioMensal;
        }

        public Mensalista() //construtor
        {
            System.Windows.Forms.MessageBox.Show("Aqui é mensalista");
        }

        //sobrecarga de matricula utilizando o construtor com parametros,pode criar varios contanto que não tenham a mesma assinatura (variaveis) 
        public Mensalista(int matx, string nomex, DateTime datax, double salx)
        {
            this.NomeEmpregado = nomex;
            this.Matricula = matx;
            this.DataEntradaEmpresa = datax;
            this.SalarioMensal = salx;
        }
    }
}
