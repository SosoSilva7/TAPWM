﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PEmpregado
{
    abstract internal class Empregado
    {
        //atributos, que são encapsulados
        private int matricula;
        private string nomeEmpregado;
        private DateTime dataEntradaEmpresa;

        //propriedades, publicos que retornam o valor do atributo
        // tem duas partes - get/set
        public int Matricula
        {
            get { return matricula; }
            set { matricula = value; }
        }

        public string NomeEmpregado
        {
            get { return nomeEmpregado; }
            set { nomeEmpregado = value; }
        }

        public DateTime DataEntradaEmpresa
        {
            get { return dataEntradaEmpresa; }
            set { dataEntradaEmpresa = value; }
        }

        //metodos são ações/comportamentos 
        //virtual --> poder ser sobreescrito
        public virtual int TempoTrabalho()
        {
            //representa um intervalo de tempo
            TimeSpan span = DateTime.Today.Subtract(DataEntradaEmpresa);
            return (span.Days);
        }

        public abstract double SalarioBruto();

        public Empregado() //construtor
        {
            System.Windows.Forms.MessageBox.Show("Aqui é empregado");
        }

    }
}
