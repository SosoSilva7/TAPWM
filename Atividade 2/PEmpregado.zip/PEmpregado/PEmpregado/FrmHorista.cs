﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PEmpregado
{
    public partial class FrmHorista : Form
    {
        public FrmHorista()
        {
            InitializeComponent();
        }

        private void btnMensalista_Click(object sender, EventArgs e)
        {
            //criando o objeto, instanciando o objeto
            Horista objHorista = new Horista();
            objHorista.NomeEmpregado = txtNome.Text;
            objHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objHorista.SalarioHora = Convert.ToDouble(txtSalario.Text);
            objHorista.NumeroHora = Convert.ToDouble(txtHoras.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtFaltas.Text);

            //mostrando valores
            MessageBox.Show("Nome = " + objHorista.NomeEmpregado +
                "\nMatrícula = " + objHorista.Matricula +
                "\nTempo Trabalho = " + objHorista.TempoTrabalho() +
                "\nSalário = " + objHorista.SalarioBruto().ToString("N2")); //converte em texto e coloca 2 casas decimais
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}
