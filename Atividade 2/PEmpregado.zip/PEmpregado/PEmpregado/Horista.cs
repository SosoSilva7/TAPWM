﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PEmpregado
{
    internal class Horista : Empregado
    // nao posso herdar mais de uma classe, não existe herança múltipla
    {
        public double SalarioHora { get; set; }
        public double NumeroHora { get; set; }
        public int DiasFalta { get; set; }

        //override indica sobreescrever
        public override double SalarioBruto()
        {
            TimeSpan span =
                DateTime.Today.Subtract(DataEntradaEmpresa);
            return (span.Days - DiasFalta);
        }

        public Horista() //construtor
        {
            System.Windows.Forms.MessageBox.Show("Aqui é horista");
        }
    }
}
